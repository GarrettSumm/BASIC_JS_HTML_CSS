function changetext(event){
    event.innerHTML = "Logout";
}

    
    
    function hide(defbutton){
        defbutton.remove();
    }
